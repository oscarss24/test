Copyright (c) 2019-2021 Doadin <doadinaddons@gmail.com>

All rights reserved.

Permission is granted for anyone to use, read, or otherwise interpret
this software for any purpose, without any restrictions.

Permission is granted for anyone to modify this software or sample from
it, and to distribute such modified versions or derivative works as long
as neither the names of this software nor its authors are used in the
name or title of the work or in any other way that may cause it to be
confused with or interfere with the simultaneous use of this software.

Permission is granted for anyone to aggregate this software with other
works not derived from this software for the purpose of creating a user
interface replacement (also commonly known as a "compilation" or "addon
pack") for the "World of Warcraft" game client, and to distribute such
collective works as long as the software is not modified in any way,
including by modifying or removing any files.

This software may not be distributed standalone or in any other way, in
whole or in part, modified or unmodified, without specific prior written
permission from the authors of this software.

The names of this software and/or its authors may not be used to
promote or endorse works derived from this software without specific
prior written permission from the authors of this software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR
OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.
